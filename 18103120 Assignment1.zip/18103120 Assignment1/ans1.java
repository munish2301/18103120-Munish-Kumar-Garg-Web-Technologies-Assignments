import java.io.*;
import java.util.*;
public class ans1{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter string:  ");
		String str=sc.nextLine();
		System.out.print("Enter substring:  ");
		String substr=sc.nextLine();
		HashMap<Character,Integer>mapsubstr=new HashMap<>();
		for(int i=0;i<substr.length();i++)
		{
			if(mapsubstr.containsKey(substr.charAt(i)))
			{
				Integer a=mapsubstr.get(substr.charAt(i));
				a+=1;
				mapsubstr.put(substr.charAt(i),a);
			}
			else
			{
				mapsubstr.put(substr.charAt(i),1);
			}
		}
		HashMap<Character,Integer>mapstr=new HashMap<>();
		int ans=0;
		for(int i=0;i<substr.length();i++)
		{
			if(mapstr.containsKey(str.charAt(i)))
			{
				Integer a=mapstr.get(str.charAt(i));
				a+=1;
				mapstr.put(str.charAt(i),a);
			}
			else
			{
				mapstr.put(str.charAt(i),1);
			}
		}
		if(mapsubstr.equals(mapstr))
			ans+=1;
		for(int i=substr.length();i<str.length();i++)
		{
			if(mapstr.containsKey(str.charAt(i-substr.length())))
			{
				if(mapstr.get(str.charAt(i-substr.length()))==1)
				{
					mapstr.remove(str.charAt(i-substr.length()));
				}
				else
				{
					Integer a=mapstr.get(str.charAt(i-substr.length()));
					a-=1;
					mapstr.put(str.charAt(i-substr.length()),a);
				}
			}
			if(mapstr.containsKey(str.charAt(i)))
			{
				Integer a=mapstr.get(str.charAt(i));
				a+=1;
				mapstr.put(str.charAt(i),a);
			}
			else
			{
				mapstr.put(str.charAt(i),1);
			}
			if(mapsubstr.equals(mapstr))
				ans+=1;
		}
		System.out.print("No. of substrings in string = ");
		System.out.print(ans);
	}
}