import java.util.*;
import java.io.*;
public class ans3{
	public static int min(int a,int b)
	{
		return (a>b)?b:a;
	}
	public static int tocompare(String str1,String str2) {
		int i;
		for(i=0;i<min(str1.length(),str2.length());i++)
		{
			if(str1.charAt(i)==str2.charAt(i))
			{
				continue;
			}
			else
			{
				break;
			}
		}
		if(i==min(str1.length(),str2.length()))
		{
			if(str1.length()==str2.length())
			{
				return 0;
			}
			else if(str1.length()>str2.length())
			{
				return 1;
			}
			else
			{
				return -1;
			}
		}
		else
		{
			if(str1.charAt(i)>str2.charAt(i))
			{
				return 1;
			}
			else
			{
				return -1;
			}
		}
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		try{
			System.out.print("Enter size of array of strings: ");
			int n=sc.nextInt();
			sc.nextLine();
			String[] arr=new String[n];
			for(int i=0;i<n;i++)
			{
				System.out.printf("Enter %dth string of the array: ",i);
				arr[i]=sc.nextLine();
			}
			for(int i=0;i<n;i++)
			{
				for(int j=i+1;j<n;j++)
				{
					int res=tocompare(arr[i],arr[j]);
					if(res==1)
					{
						String swap=arr[i];
						arr[i]=arr[j];
						arr[j]=swap;
					}
				}
			}
			System.out.println("Sorted array is (in increasing order): ");
			for(int i=0;i<n;i++)
			{
				System.out.print("\""+arr[i]+"\" ");
			}
		}
		catch(InputMismatchException e)
		{
			System.out.println("You have entered something wrong! Value must be of suitable Datatype.");
		}
	}
}