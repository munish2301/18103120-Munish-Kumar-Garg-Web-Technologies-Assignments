import java.util.*;
import java.io.*;
public class ans1{
	public static int min(int a,int b)
	{
		return (a>b)?b:a;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter first string: ");
		String str1,str2;
		str1=sc.nextLine();
		System.out.print("Enter second string: ");
		str2=sc.nextLine();
		int i;
		for(i=0;i<min(str1.length(),str2.length());i++)
		{
			if(str1.charAt(i)==str2.charAt(i))
			{
				continue;
			}
			else
			{
				break;
			}
		}
		if(i==min(str1.length(),str2.length()))
		{
			if(str1.length()==str2.length())
			{
				System.out.printf("Both strings are lexicographical equal."+" Return value is: %d",str1.length()-str2.length());
			}
			else if(str1.length()>str2.length())
			{
				System.out.printf(str1+" is lexicographical greater than "+str2+"."+" Return value is: %d",str1.length()-str2.length());
			}
			else
			{
				System.out.printf(str1+" is lexicographical smaller than "+str2+"."+" Return value is: %d",str1.length()-str2.length());
			}
		}
		else
		{
			if(str1.charAt(i)>str2.charAt(i))
			{
				System.out.printf(str1+" is lexicographical greater than "+str2+"."+" Return value is: %d",(int)str1.charAt(i)-(int)str2.charAt(i));
			}
			else
			{
				System.out.printf(str1+" is lexicographical smaller than "+str2+"."+" Return value is: %d",(int)str1.charAt(i)-(int)str2.charAt(i));
			}
		}
	}
}