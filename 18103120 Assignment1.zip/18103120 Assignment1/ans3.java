import java.io.*;
import java.util.*;
public class ans3{
	class edge{
		int source,destination,val;
		edge()
		{
			this.source=0;
			this.destination=0;
			this.val=0;
		}
	};
	int v;
	int e;
	edge[] vect;
	final static int inf=10000000;
	static boolean is_there_neg_cycle=false;
	ans3(int vert,int edg)
	{
		this.v=vert;
		this.e=edg;
		this.vect=new edge[edg];
		for(int i=0;i<edg;i++)
		{
			vect[i]=new edge();
		}
	}
	void mymethod(ans3 graph,int src,int dest)
	{
		int numofvert=graph.v;
		int numofedges=graph.e;
		int distance[]=new int[numofvert];
		for(int i=0;i<numofvert;i++)
		{
			distance[i]=Integer.MAX_VALUE;
		}
		distance[src]=0;
		for(int i=1;i<numofvert;i++)
		{
			for(int j=0;j<numofedges;j++)
			{
				int u=graph.vect[j].source;
				int v=graph.vect[j].destination;
				int cost=graph.vect[j].val;
				if(distance[u]!=Integer.MAX_VALUE&&distance[u]+cost<distance[v])
				{
					distance[v]=distance[u]+cost;
				}
			}
		}
		for(int j=0;j<numofedges;j++)
		{
			int u=graph.vect[j].source;
			int v=graph.vect[j].destination;
			int cost=graph.vect[j].val;
			if(distance[u]!=Integer.MAX_VALUE&&distance[u]+cost<distance[v])
			{
				is_there_neg_cycle=true;
				System.out.println("Negative Weight Cycle Exists.");
				return ;
			}
		}
		if(distance[dest]==Integer.MAX_VALUE)
		{
			System.out.println("There is no path between source and destination provided by you.");
			return ;
		}
		System.out.printf("The minimum cost of given source-destination pair (calculated using Bellman Ford Algorithm) is: %d unit",distance[dest]);
		System.out.println();
		return ;
	}
	void allpair(ans3 graph)
	{
		int numofvert=graph.v;
		int numofedges=graph.e;
		int distance[][]=new int[numofvert][numofvert];
		for(int i=0;i<numofvert;i++)
		{
			for(int j=0;j<numofvert;j++)
			{
				if(i==j)
					continue;
				else
					distance[i][j]=inf;
			}
		}
		for(int i=0;i<numofedges;i++)
		{
			if(distance[graph.vect[i].source][graph.vect[i].destination]!=inf)
			{
				if(distance[graph.vect[i].source][graph.vect[i].destination]>graph.vect[i].val)
				{
					distance[graph.vect[i].source][graph.vect[i].destination]=graph.vect[i].val;
				}
			}
			else
				distance[graph.vect[i].source][graph.vect[i].destination]=graph.vect[i].val;
		}
		for(int k=0;k<numofvert;k++)
		{
			for(int i=0;i<numofvert;i++)
			{
				for(int j=0;j<numofvert;j++)
				{
					if(distance[i][k]+distance[k][j]<distance[i][j]&&(distance[i][k]!=inf&&distance[k][j]!=inf))
						distance[i][j]=distance[i][k]+distance[k][j];
				}
			}
		}
		System.out.println();
		System.out.println("All Pair Shortest Paths (calculated using Floyd Warshall's Algorithm) are:   ");
		for(int i=0;i<numofvert;i++)
		{
			for(int j=0;j<numofvert;j++)
			{
				if(distance[i][j]!=inf)
					System.out.printf("from %d to %d is %d.",i,j,distance[i][j]);
				else
					System.out.printf("No path from %d to %d.",i,j);
				System.out.println();
			}
		}
	}
	public static void main(String[] args) {
		System.out.println("NOTE: Input Graph is Undirected Graph. So you have to beware of entering negative weights. Enter an edge only once from source to destination. Interally it also creates edge from destination to source because it is Undirected Graph.");
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter number of vertices: ");
		int nodes=sc.nextInt();
		sc.nextLine();
		System.out.print("Enter number of edges: ");
		int edges=sc.nextInt();
		edges*=2;
		sc.nextLine();
		ans3 graph=new ans3(nodes,edges);
		for(int i=0;i<edges/2;i++)
		{
			System.out.printf("Enter source of %dth edge:  ",i);
			graph.vect[i].source=sc.nextInt();
			sc.nextLine();
			System.out.printf("Enter destination of %dth edge:  ",i);
			graph.vect[i].destination=sc.nextInt();
			sc.nextLine();
			System.out.printf("Enter weight of %dth edge:  ",i);
			graph.vect[i].val=sc.nextInt();
			sc.nextLine();			
			int stemp,dtemp,wtemp;
			stemp=graph.vect[i].source;
			dtemp=graph.vect[i].destination;
			wtemp=graph.vect[i].val;
			graph.vect[i+(edges/2)].source=dtemp;
			graph.vect[i+(edges/2)].destination=stemp;
			graph.vect[i+(edges/2)].val=wtemp;
		}
		System.out.print("Enter the source from which you want to find the minimum distance: ");
		int src=sc.nextInt();
		sc.nextLine();
		System.out.print("Enter the destination to which you want to find the minimum distance: ");
		int dest=sc.nextInt();
		sc.nextLine();
		graph.mymethod(graph,src,dest);
		if(is_there_neg_cycle==false){
		System.out.println("For Calculating All Pair Shortest Paths (provided negative weighted cycle doesnot exists in the graph): Press 1 \nElse: Press 2");
		int find=sc.nextInt();
		if(find==1)
		    graph.allpair(graph);
		else
			return ;}
	}
}
// for finding shortest distance between two points, we have to implement Bellman Ford's Algorithm because graph may contain negative weighted edges.
// for all pair shortest paths, we have to implement Floyd Warshall's Algorithm. 
// for calculating all possible paths between two nodes, we can go for DFS, but this dynamic programming solution approach (Bellman Ford) is unable to calculate all possible paths.