import java.util.*;
import java.io.*;
public class ans4{
	public static void main(String[] args) {
		int n=1;
        int sum=1;
        int i=1;
        while(n<Integer.MAX_VALUE)
        {
            if(sum==n*n)
            {
                System.out.printf("The %dst minimum value of n is: "+n,i);
                i++;
                System.out.println();
            }
            n++;
            sum+=n;
        }
    }
}