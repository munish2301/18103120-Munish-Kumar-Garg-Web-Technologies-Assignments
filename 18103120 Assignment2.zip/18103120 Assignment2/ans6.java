import java.util.*;
import java.io.*;
public class ans6 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		try{
			System.out.print("Enter a positive number (integer): ");
			int n=sc.nextInt();
			boolean error=false;
			if(n<=0)
			{
				System.out.println("You have entered a wrong input. Number must be greater than 0.");
				return;
			}
			System.out.println("Hailstone Sequence for the provided number is: ");
			while(n!=1)
			{
				if(n%2==0)
				{
					System.out.println(n+" is even. So, dividing by 2.");
					n/=2;
				}
				else
				{
				    System.out.println(n+" is odd. So, multiplying by 3 and add 1");
				    n=3*n+1;
				    if(n<0)
				    {
				    	System.out.println("Out of integer bound!");
				    	error=true;
				    	break;
				    }
				}
			}
			if(error==false)
				System.out.println("Finally 1.");
		}
		catch(InputMismatchException e)
		{
			System.out.println("You have entered something wrong! Value must be of suitable Datatype.");
		}
	}
}